-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2020 at 08:40 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penjualanbuku`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id_buku` varchar(90) DEFAULT NULL,
  `id_kategori` varchar(90) DEFAULT NULL,
  `judul` varchar(90) DEFAULT NULL,
  `harga` varchar(90) DEFAULT NULL,
  `gambar` varchar(90) DEFAULT NULL,
  `keterangan` varchar(90) DEFAULT NULL,
  `pengarang` varchar(90) DEFAULT NULL,
  `stok` varchar(90) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `id_kategori`, `judul`, `harga`, `gambar`, `keterangan`, `pengarang`, `stok`) VALUES
('2', '2', 'ppkn', '120000', 'gambar.jpg', 'lunas', 'airlangga', '180'),
('3', '3', 'sejarah', '120000', 'gambar.jpg', 'lunas', 'airlangga', '150'),
('4', '4', 'matematika', '120000', 'gambar.jpg', 'lunas', 'airlangga', '150'),
('5', '5', 'bahasa jawa', '120000', 'gambar.jpg', 'lunas', 'airlangga', '150');

-- --------------------------------------------------------

--
-- Table structure for table `detail_jual`
--

CREATE TABLE `detail_jual` (
  `id_transaksi` varchar(90) DEFAULT NULL,
  `id_buku` varchar(90) DEFAULT NULL,
  `jumlah` varchar(90) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `detail_jual`
--

INSERT INTO `detail_jual` (`id_transaksi`, `id_buku`, `jumlah`) VALUES
('2', '2', '10');

--
-- Triggers `detail_jual`
--
DELIMITER $$
CREATE TRIGGER `kurangistok` AFTER INSERT ON `detail_jual` FOR EACH ROW UPDATE buku SET stok = stok-NEW.jumlah WHERE id_buku = NEW.id_buku
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` varchar(90) DEFAULT NULL,
  `keterangan` varchar(90) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `keterangan`) VALUES
('1', 'lunas');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` varchar(90) DEFAULT NULL,
  `nama` varchar(90) DEFAULT NULL,
  `alamat` varchar(90) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama`, `alamat`) VALUES
('1', 'Angga', 'Tanggul');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `id_transaksi` varchar(90) DEFAULT NULL,
  `id_pelanggan` varchar(90) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`id_transaksi`, `id_pelanggan`) VALUES
('1', '1');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
