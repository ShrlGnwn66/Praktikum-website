<?php 
include 'koneksi.php';
 ?>

 <?php 

$id_buku = $_GET['id_buku'];
$tampil = $conn->query("select * from buku where id_buku=$id_buku");
foreach ($tampil as $baris) {
	
?>
  <form method="POST">
  	<label>id_buku</label>
  	<input type="text" name="id_buku" value="<?=$baris['id_buku']?>">
  	<br>
  	<label>id_kategori</label>
  	<input type="text" name="id_kategori" value="<?=$baris['id_kategori']?>">
  	<br>
  	<label>judul_buku</label>
  	<input type="text" name="judul" value="<?=$baris['judul']?>">
  	<br>
  	<label>harga</label>
  	<input type="text" name="harga" value="<?=$baris['harga']?>">
  	<br>
  	<label>gambar</label>
  	<input type="text" name="gambar" value="<?=$baris['gambar']?>">
  	<br>
  	<label>keterangan</label>
  	<input type="text" name="keterangan" value="<?=$baris['keterangan']?>">
  	<br>
  	<label>pengarang</label>
  	<input type="text" name="pengarang" value="<?=$baris['pengarang']?>">
  	<br>
  	<label>stok</label>
  	<input type="text" name="stok" value="<?=$baris['stok']?>">
  	<br>
  	<button type="submit" name="ubah">simpan</button>
  </form>
  <?php } ?>

<?php 
if (isset($_POST['ubah'])) {
$id_kategori = $_POST['id_kategori'];
$judul = $_POST['judul'];
$harga = $_POST['harga'];
$gambar = $_POST['gambar'];
$keterangan = $_POST['keterangan'];
$pengarang = $_POST['pengarang'];
$stok = $_POST['stok'];

$ubah = $conn->query("update buku set id_kategori = '$id_kategori',
									 judul = '$judul',
									 gambar = '$gambar',
									 keterangan = '$keterangan',
									 pengarang = '$pengarang',
									 stok = '$stok' where id_buku = $id_buku
									 ");

if ($ubah) {
	echo"<script>alert('berhasil ditambah');window.location.href='index.php';</script>";
	}else{
	echo"<script>alert('gagal ditambah');window.location.href='index.php';</script>";
	}

}
   ?>