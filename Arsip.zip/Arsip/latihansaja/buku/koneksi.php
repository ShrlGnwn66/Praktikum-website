<?php 
$conn = new mysqli('localhost','root','','penjualanbuku');
 ?>