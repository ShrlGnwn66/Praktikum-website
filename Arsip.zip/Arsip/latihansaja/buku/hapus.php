<?php

//2

//include file koneksi
include 'koneksi.php';

//ambil kiriman id_kategori
$id_buku = $_GET['id_buku'];


$hapus =$conn->query("delete from buku where id_buku =$id_buku");


if($hapus){
    echo"<script>alert('berhasi dihapus'); window.location.href='index.php';</script>";
} else {
	echo"<script>alert('gagal dihapus'); </script>";
}
