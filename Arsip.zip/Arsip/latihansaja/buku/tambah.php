<?php 
include 'koneksi.php';
 ?>
<form action="" method="POST" enctype="multipart/form-data">
  <table width="452" border="0" align="left" cellpadding="0" cellspacing="1" bgcolor="white" style="padding: 2px">
 	<tr>
 		<td width="113">Id Buku</td>
 		<td width="150"><input type="text" name="id_buku" size="30" maxlength="30"></td>
 	</tr>
 	<tr>
 		<td width="113">Id Kategori</td>
 		<td width="210"><input type="text" name="id_kategori" size="30" maxlength="30"></td>
 	</tr>
 	<tr>
 		<td width="113">Judul</td>
 		<td width="220"><input type="text" name="judul" size="30" maxlength="30"></td>
 	</tr>
	<tr>
 		<td width="113">Harga</td>
 		<td width="220"><input type="text" name="harga" size="30" maxlength="30"></td>
 	</tr>
	<tr>
 		<td width="113">Gambar</td>
 		<td width="220"><input type="text" name="gambar" size="30" maxlength="30"></td>
 	</tr>
	<tr>
 		<td width="113">Keterangan</td>
 		<td width="220"><input type="text" name="keterangan" size="30" maxlength="30"></td>
 	</tr>
	<tr>
 		<td width="113">Pengarang</td>
 		<td width="220"><input type="text" name="pengarang" size="30" maxlength="30"></td>
 	</tr>
	<tr>
 		<td width="113">Stok</td>
 		<td width="220"><input type="text" name="stok" size="30" maxlength="30"></td>
 	</tr>
 	<tr>
		 <td></td>
 		<td><input type="submit" name="simpan" value="SIMPAN">  <input type="reset" value="RESET"></td>
 		<td></td>
 	</tr>
  </table> 
</form>

 <?php 
if (isset($_POST['simpan'])) {
$id_buku = $_POST['id_buku'];
$id_kategori = $_POST['id_kategori'];
$judul = $_POST['judul'];
$harga = $_POST['harga'];
$gambar = $_POST['gambar'];
$keterangan = $_POST['keterangan'];
$pengarang = $_POST['pengarang'];
$stok = $_POST['stok'];

$tambah = $conn->query("insert into buku values('$id_buku','$id_kategori','$judul','$harga','$gambar','$keterangan','$pengarang','$stok')");

if ($tambah) {
	echo"<script>alert('berhasil ditambah');window.location.href='index.php';</script>";
	}else{
	echo"<script>alert('gagal ditambah');window.location.href='index.php';</script>";
	}
}
  ?>