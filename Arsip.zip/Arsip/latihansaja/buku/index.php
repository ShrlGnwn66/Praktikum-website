<?php 
include 'koneksi.php';
 ?>
 <a href="tambah.php">+ Tambah</a>
 <table border="2">
 	<tr bgcolor="red">
 		<th>Id Buku</th>
 		<th>Id Kategori</th>
 		<th>Judul</th>
 		<th>Harga</th>
 		<th>Gambar</th>
 		<th>Keterangan</th>
 		<th>Pengarang</th>
 		<th>Stok</th>
 		<th>Aksi</th>
 	</tr>
<?php 
$tampil = $conn->query("select * from buku");
foreach ($tampil as $baris) {
 ?>
 	<tr>
 		<td><?=$baris['id_buku']?></td>
 		<td><?=$baris['id_kategori']?></td>
 		<td><?=$baris['judul']?></td>
 		<td><?=$baris['harga']?></td>
 		<td><?=$baris['gambar']?></td>
 		<td><?=$baris['keterangan']?></td>
 		<td><?=$baris['pengarang']?></td>
 		<td><?=$baris['stok']?></td>
 		<td><a href="hapus.php?id_buku=<?=$baris['id_buku']?>">Hapus</a>
 			<a href="edit.php?id_buku=<?=$baris['id_buku']?>">Edit</a></td>
 	</tr>
<?php } ?>
 </table>